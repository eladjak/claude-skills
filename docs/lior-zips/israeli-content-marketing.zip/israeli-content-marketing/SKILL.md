---
name: israeli-content-marketing
description: >-
  Plan and execute content marketing strategies for the Israeli market including
  Hebrew SEO content, tech media outreach to Geektime and Calcalist, and B2B
  content. Use when user asks about Israeli content strategy, Hebrew blog posts,
  Israeli tech PR, or Hebrew B2B content. Covers Israeli tech media landscape,
  Hebrew content SEO, and bilingual content strategies.
license: MIT
compatibility: >-
  Works with Claude Code, Cursor, GitHub Copilot, Windsurf, OpenCode, Codex.
metadata:
  author: skills-il
  version: 1.0.0
  category: marketing-growth
  tags:
    he:
      - שיווק-תוכן
      - בלוג
      - SEO
      - יחסי-ציבור
      - B2B
      - תוכן-שיווקי
    en:
      - content-marketing
      - blog
      - seo
      - public-relations
      - b2b
      - marketing-content
  display_name:
    he: "שיווק תוכן ישראלי"
    en: "Israeli Content Marketing"
  display_description:
    he: >-
      תכנון וביצוע אסטרטגיית שיווק תוכן לשוק הישראלי כולל SEO בעברית, PR
      טכנולוגי לאתרים כמו Geektime וכלכליסט, ותוכן B2B
    en: >-
      Plan and execute content marketing strategies for the Israeli market
      including Hebrew SEO content, tech media outreach, and B2B content
  supported_agents:
    - claude-code
    - cursor
    - github-copilot
    - windsurf
    - opencode
    - codex
    - antigravity
---

# Israeli Content Marketing

## Instructions

### Israeli Media Landscape
Key outlets: Geektime (tech blog), Calcalist Tech (business+tech), The Marker (business), Globes (business), Ynet Tech (general), CTech (English). Mobile-first consumption (>70%). Facebook groups are major content discovery channel.

### Hebrew SEO Content Strategy
Use Google Keyword Planner with Israel location. Check Google Trends Israel. URL slugs: transliterated Hebrew or English (avoid encoded Hebrew). Structure: H2 every 200-300 words, short paragraphs (2-3 sentences).

### Content Types for Israeli Market
B2B: Case studies with Israeli clients (very high effectiveness), data-driven reports, Hebrew webinars, how-to guides. B2C: Buying guides with NIS pricing, Hebrew reviews, seasonal content tied to Jewish holidays.

### Israeli Tech PR
Keep pitches brief and direct. WhatsApp follow-ups acceptable. Include quick facts: founding, team size, funding, traction. Hebrew pitches for Hebrew outlets; English for CTech, No Camels.

### Content Distribution
Google SEO, Facebook groups (value-first), LinkedIn (B2B), email newsletter (Chok HaSpam compliant), WhatsApp (viral), Telegram (tech communities).

### Repurposing
Blog post -> social snippets -> email summary -> LinkedIn article -> video -> infographic.

## Examples

### Example 1: Create Hebrew Blog Content Calendar
User says: "Plan a 3-month content calendar for our Israeli SaaS blog"
Actions:
1. Identify Hebrew keyword clusters for the industry
2. Map content to Israeli business calendar (avoid holidays, leverage events)
3. Plan weekly cadence: 1 long-form post + 2 social snippets
4. Include Hebrew SEO optimization for each piece
5. Assign distribution channels (LinkedIn IL, Facebook groups, Calcalist)
Result: 12-week Hebrew content calendar with SEO targets and distribution plan

### Example 2: Write Hebrew Thought Leadership Article
User says: "Write an article about AI trends for Israeli tech audience"
Actions:
1. Research trending topics in Israeli tech press (Geektime, Calcalist Tech)
2. Write 1500-word Hebrew article with data and expert quotes
3. Optimize for Hebrew SEO with meta description and headers
4. Create social snippets for LinkedIn and Twitter
Result: Publishable Hebrew tech article with social distribution kit

## Bundled Resources

### Scripts
- `scripts/content_calendar.py` -- Generates content calendars accounting for Israeli holidays and business cycles. Run: `python scripts/content_calendar.py --help`

### References
- `references/israeli-media-landscape.md` -- Israeli media outlets, tech publications, content distribution channels, and audience demographics. Consult when planning content distribution or media outreach.

## Troubleshooting

### Error: "Content not ranking for Hebrew keywords"
Cause: Hebrew SEO requires different optimization than English
Solution: Use exact Hebrew phrases (not transliterations), include common misspellings, and ensure proper hreflang tags for he-IL locale.

### Error: "Low engagement on Israeli social platforms"
Cause: Content timing or format mismatch with Israeli audience habits
Solution: Post Sunday-Thursday (Israeli work week), peak times 8-9am and 12-1pm. Israeli audiences prefer informal tone and local references over corporate language.
